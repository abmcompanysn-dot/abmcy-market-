const categories = [
    { name: 'Électronique', href: 'categorie.html' },
    { name: 'Vêtements', href: 'categorie.html' },
    { name: 'Maison & Décoration', href: 'categorie.html' },
    { name: 'Beauté & Soins', href: 'categorie.html' },
    { name: 'Sports & Loisirs', href: 'categorie.html' },
    { name: 'Livres & Médias', href: 'categorie.html' },
    { name: 'Promotions', href: 'promotions.html' },
    { name: 'Contact', href: 'contact.html' }
];