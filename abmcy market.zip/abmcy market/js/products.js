const allProducts = [
    { id: 1, name: 'Smartphone Pro', price: 450000, icon: '📱', category: 'Électronique' },
    { id: 2, name: 'Laptop Gaming', price: 780000, icon: '💻', category: 'Électronique' },
    { id: 3, name: 'Casque Audio', price: 58000, icon: '🎧', category: 'Électronique' },
    { id: 4, name: 'Montre Connectée', price: 155000, icon: '⌚', category: 'Électronique' },
    { id: 5, name: 'T-shirt Premium', price: 15000, icon: '👕', category: 'Vêtements' },
    { id: 6, name: 'Jean Slim', price: 42000, icon: '👖', category: 'Vêtements' },
    { id: 7, name: 'Robe Élégante', price: 50000, icon: '👗', category: 'Vêtements' },
    { id: 8, name: 'Veste d\'Hiver', price: 90000, icon: '🧥', category: 'Vêtements' },
    { id: 9, name: 'Canapé Moderne', price: 580000, icon: '🛋️', category: 'Maison' },
    { id: 10, name: 'Lampe Design', price: 38000, icon: '💡', category: 'Maison' },
    { id: 11, name: 'Tableau Artistique', price: 84000, icon: '🖼️', category: 'Maison' },
    { id: 12, name: 'Plante Décorative', price: 25000, icon: '🪴', category: 'Maison' }
];